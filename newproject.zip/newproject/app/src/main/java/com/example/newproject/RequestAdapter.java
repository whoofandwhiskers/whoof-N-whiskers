package com.example.newproject;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.List;

class RequestAdapter extends RecyclerView.Adapter<RequestAdapter.RequestViewHolder> {

    private List<Request> requestList;

    public RequestAdapter(List<Request> requestList) {

        this.requestList = requestList;
    }

    @NonNull
    @Override
    public RequestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.newitem, parent, false);
        return new RequestViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull RequestViewHolder holder, int position) {
        Request request = requestList.get(position);
        holder.senderNameTextView.setText(request.getSenderemail());
        holder.messageTextView.setText(request.getMessage());

        holder.acceptButton.setOnClickListener(v -> {
            // Handle decline button click
            request.setStatus("accpeted");
            updateRequestStatus(request);
            Toast.makeText(holder.declineButton.getContext(), "Request declined", Toast.LENGTH_SHORT).show();

        });
        holder.declineButton.setOnClickListener(v -> {
            // Handle decline button click
            request.setStatus("declined");
            updateRequestStatus(request);
            Toast.makeText(holder.declineButton.getContext(), "Request declined", Toast.LENGTH_SHORT).show();

        });
    }

    @Override
    public int getItemCount() {
        return requestList.size();
    }

    public void setRequestList(List<Request> requestList) {
        this.requestList = requestList;
        notifyDataSetChanged();
    }

    static class RequestViewHolder extends RecyclerView.ViewHolder {
        TextView senderNameTextView;
        TextView messageTextView;
        Button acceptButton;
        Button declineButton;

        RequestViewHolder(@NonNull View itemView) {
            super(itemView);
            senderNameTextView = itemView.findViewById(R.id.sender_name);
            messageTextView = itemView.findViewById(R.id.message);
            acceptButton = itemView.findViewById(R.id.accept_button);
            declineButton = itemView.findViewById(R.id.decline_button);




        }



    }

    private void updateRequestStatus(Request request) {
        DatabaseReference requestsRef = FirebaseDatabase.getInstance().getReference("requests");
        String requestId = request.getId();// You need to add an id field to the Request class
        Log.d("RequestAdapter", "Updating request status for request with id " + requestId);
        requestsRef.child(requestId).setValue(request)
                .addOnSuccessListener(aVoid -> {
                    Log.d("RequestAdapter", "Request status updated successfully");



                    // You can show a toast, update the UI, or do nothing
                })
                .addOnFailureListener(e -> {
                    // Handle the failure, e.g., show a toast or a dialog
                    Log.e("RequestAdapter", "Failed to update request status", e);
                });
    }

}