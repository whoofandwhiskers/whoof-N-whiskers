package com.example.newproject;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;

import org.checkerframework.checker.nullness.qual.NonNull;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class owner_home_page extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner_home_page);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        btn=findViewById(R.id.logout_button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(owner_home_page.this, login_page.class);
                startActivity(intent);
            }
        });
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.navigation_Find_Host)
                {
                    Intent intent = new Intent(owner_home_page.this, viewmap.class);
                    startActivity(intent);
                    return true;
                } else if (item.getItemId() == R.id.navigation_Location) {
                    // Handle menu item 2
                    return true;
                } else if (item.getItemId() == R.id.navigation_List) {

                    Intent intent = new Intent(owner_home_page.this, userlist.class);
                    startActivity(intent);
                    // Handle menu item 3
                    return true;

                } else if (item.getItemId() == R.id.navigation_live_chat) {


                    // Handle menu item 3
                    return true;

                }


                else {
                    return false;
                }
            }
        });
    }
}
