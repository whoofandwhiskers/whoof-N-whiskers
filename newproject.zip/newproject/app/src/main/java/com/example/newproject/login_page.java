package com.example.newproject;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class login_page extends AppCompatActivity {

    Button signupfromlogin, afterlogin;
    private FirebaseAuth auth1;
    EditText log, sign;
    Spinner spinner1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        auth1 = FirebaseAuth.getInstance();
        signupfromlogin = findViewById(R.id.sing_up);//button
        afterlogin = findViewById(R.id.login_button);//button
        log = findViewById(R.id.email_login);//text field
        sign = findViewById(R.id.password_login);//text field
        spinner1 = findViewById(R.id.spinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.usertype, com.karumi.dexter.R.layout.support_simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter);


        signupfromlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(login_page.this, choice_page.class));
                finish();
            }
        });

        afterlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //one line to check if the email has been registred
                final String email_login = log.getText().toString();
                final String pass_login = sign.getText().toString();
                String item = spinner1.getSelectedItem().toString();


                if (TextUtils.isEmpty(email_login)) {
                    log.setError("Email is required");
                    return;
                }

                if (!email_login.matches("[a-zA-Z0-9._-]+@[a-z]+\\.[a-z]+")) {
                    log.setError("Invalid email format");
                    return;
                }

                if (TextUtils.isEmpty(pass_login)) {
                    sign.setError("Password is required");
                    return;
                }


                auth1.signInWithEmailAndPassword(email_login, pass_login)
                        .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                            @Override
                            public void onSuccess(AuthResult authResult) {

                                if (item.equals("host")) {
                                    startActivity(new Intent(login_page.this, host_home_page.class));
                                    finish();
                                } else if (item.equals("owner")) {
                                    startActivity(new Intent(login_page.this, owner_home_page.class));
                                    finish();
                                } else {
                                    Toast.makeText(login_page.this, "Error", Toast.LENGTH_SHORT).show();
                                }


                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@androidx.annotation.NonNull Exception e) {

                                log.setError("this email is not registered");

                                return;
                            }
                        });

            }

        });
    }
}






                /*if(!email_login.isEmpty()){
                    if(!pass_login.isEmpty()){
                        auth1.signInWithEmailAndPassword(email_login,pass_login)
                                .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                                    @Override
                                    public void onSuccess(AuthResult authResult) {
                                        startActivity(new Intent(login_page.this, afterlogin.class));
                                        finish();

                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {

                                        log.setError("this email is not registered");

                                        return;
                                    }
                                });
                    }
                }





            }
        });*/


