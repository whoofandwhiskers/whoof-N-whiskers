package com.example.newproject;

public class User {
    String first_name, email;


    public String getEmail() {
        return email;
    }

    public String getFirst_name() {
        return first_name;
    }
}


